package com.example.student_connect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
